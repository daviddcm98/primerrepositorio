

public class alumno {
	String nombre;
	String apellido1;
	String apellido2;
	int clase;
	
public String getNombre() {
	return nombre;
}
public void setNombre(String name) {
	this.nombre=name;
	
}
public String getApellido1() {
	return apellido1;
}
public int getClase() {
	return clase;
}
public void setClase(int definida) {
	this.clase = definida;
}
public void setApellido1(String surname1) {
	this.apellido1 = surname1;
}
public String getApellido2() {
	return apellido2;
}
public void setApellido2(String surname2) {
	this.apellido2 = surname2;
}

public alumno(String name, String apel1, String apel2, int clas) {
	this.nombre=name;
	this.apellido1=apel1;
	this.apellido2=apel2;
	this.clase=clas;
}
}